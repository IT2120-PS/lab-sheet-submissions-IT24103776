setwd("C:\\Users\\hasar\\OneDrive\\Desktop\\IT24103776\\Lab 06")

# QUESTION 1: Drug Treatment Problem

# - Success rate: 92% (p = 0.92)
# - Sample size: 44 children (n = 44)
# - X = number of children cured

n1 <- 44
p1 <- 0.92

print("i. Distribution of X:")
print("X follows Binomial distribution: X ~ Binomial(n=44, p=0.92)")

prob_40 <- dbinom(40, size = n1, prob = p1)
print(paste("ii. P(X = 40) =", round(prob_40, 6)))

prob_leq_35 <- pbinom(35, size = n1, prob = p1)
print(paste("iii. P(X ≤ 35) =", round(prob_leq_35, 6)))

prob_geq_38 <- 1 - pbinom(37, size = n1, prob = p1)
print(paste("iv. P(X ≥ 38) =", round(prob_geq_38, 6)))

prob_40_to_42 <- pbinom(42, size = n1, prob = p1) - pbinom(39, size = n1, prob = p1)
print(paste("v. P(40 ≤ X ≤ 42) =", round(prob_40_to_42, 6)))


# QUESTION 2: Hospital Births Problem

# - Average births per day: 5 (λ = 5)
# - X = number of babies born per day

lambda2 <- 5

print("i. Random variable X:")
print("X = Number of babies born in the hospital per day")

print("ii. Distribution of X:")
print("X follows Poisson distribution: X ~ Poisson(λ=5)")

prob_6_babies <- dpois(6, lambda = lambda2)
print(paste("iii. P(X = 6) =", round(prob_6_babies, 6)))

prob_more_than_6 <- 1 - ppois(6, lambda = lambda2)
print(paste("iv. P(X > 6) =", round(prob_more_than_6, 6)))







# EXERCISE : Task 1 : Learning Platform Problem

# - Success rate: 85% (p = 0.85)
# - Sample size: 50 students (n = 50)
# - X = number of students who passed

n_ex1 <- 50
p_ex1 <- 0.85

print("i. Distribution of X:")
print("X follows Binomial distribution: X ~ Binomial(n=50, p=0.85)")

prob_geq_47 <- 1 - pbinom(46, size = n_ex1, prob = p_ex1)
print(paste("ii. P(X ≥ 47) =", round(prob_geq_47, 6)))


# EXERCISE : Task 2 : Call Center Problem

# - Average calls per hour: 12 (λ = 12)
# - X = number of calls per hour

lambda_ex2 <- 12

print("i. Random variable X:")
print("X = Number of customer calls received per hour")

print("ii. Distribution of X:")
print("X follows Poisson distribution: X ~ Poisson(λ=12)")

prob_15_calls <- dpois(15, lambda = lambda_ex2)
Aprint(paste("iii. P(X = 15) =", round(prob_15_calls, 6)))