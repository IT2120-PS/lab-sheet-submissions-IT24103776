setwd("C:\\Users\\IT24103776\\Desktop\\IT24103776-Lab04")

data<-read.table("DATA 4.txt",header=TRUE,sep="")
fix(data)
attach(data)

boxplot(X1,main="Box plot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Year",outline=TRUE,outpch=8,horizontal=TRUE)

hist(X1,ylab="Frequency",xlab="Team Attendence",main="Histogram for Team Attendence")
hist(X2,ylab="Frequency",xlab="Team Salary",main="Histogram for Team Salary")
hist(X3,ylab="Frequency",xlab="Years",main="Histogram for Years")

stem(X1)
stem(X2)
stem(X3)

mean(X1)
mean(X2)
mean(X3)

median(X1)
median(X2)
median(X3)

sd(X1)
sd(X2)
sd(X3)

summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X1)[2]
quantile(X1)[4]

IQR(X1)
IQR(X2)
IQR(X3)








branch_data<-read.csv("Exercise.txt")
fix(branch_data)
head(branch_data)
detach(branch_data)

str(branch_data)

boxplot(X1,main="Box plot for Sales",outline=TRUE,outpch=8,horizontal=TRUE,ylab="Sales",col="lightblue")

fivenum(branch_data$Advertising, na.rm = TRUE)

IQR_of_Advertising<-IQR(branch_data$Advertising, na.rm = TRUE)
IQR_of_Advertising

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

outliers_years <- find_outliers(branch_data$Years_X3)
print(outliers_years)
