setwd("C:\\Users\\hasar\\OneDrive\\Desktop\\IT24103776_Lab_05")
data<-read.table("Data.txt", header = TRUE, sep = ",")
data
fix(data)
names(data)<-c("X1", "X2")

fix(data)
attach(data)
hist(X2, main = "Histogram for Number of Stakeholders")

histogram<- hist(X2, main = "Histogrm for Number of Shareholders", breaks = seq(130, 270, length = 8),right = FALSE)#right boundary value is not included

breaks<- round(histogram$breaks)
breaks
freq<-histogram$counts
freq
mids<-histogram$mids
mids
classes<-c()
for (i in 1:length(breaks)-1) {
  classes[i]<- paste0("[", breaks[i],",",breaks[i+1],")")
}
cbind(Classes = classes, Frequency = freq)

lines(mids, freq)
plot(mids, freq, type = 'l', main = "Fequency Polygon for Shareholders", xlab = "Shareholders", ylab = "Frequency", ylim = c(0,max(freq)))
plot(mids, freq, type = 'o', main = "Fequency Polygon for Shareholders", xlab = "Shareholders", ylab = "Frequency", ylim = c(0,max(freq)))
plot(mids, freq, type = 'p', main = "Fequency Polygon for Shareholders", xlab = "Shareholders", ylab = "Frequency", ylim = c(0,max(freq)))

cum.freq<- cumsum(freq)
new<-c()
for (i in 1:length(breaks)) {
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}
plot(breaks,new,type = "l",main = "cumalative frequency polygon for shareholders",
     xlab = "shareholders",ylab = "cumalative frequency",ylim = c(0,max(cum.freq)))
cbind(Upper = breaks,cumFreq = new)