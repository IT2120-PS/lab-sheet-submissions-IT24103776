
setwd("C:\\Users\\hasar\\OneDrive\\Desktop\\IT24103776_Lab_05")

Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE,sep=",")
fix(Delivery_Times)
names(Delivery_Times)<- c("DeliveryTime")
attach(Delivery_Times)

histogram <- hist(DeliveryTime,main = "Histogram for deliver times",xlab = "Delivery Time", breaks = seq(20,70,length = 10),right = FALSE)
breaks<-round(histogram$breaks)
breaks

freq <- histogram$counts
freq

cum_freq <- cumsum(freq)
cum_freq

ogive_breaks <- breaks
ogive_cum_freq <- c(0, cum_freq)

plot(ogive_breaks, ogive_cum_freq,
     type = "l", 
     main = "Ogive (Cumulative Frequency Polygon) for Delivery Times",
     xlab = "Delivery Time (Upper Class Limit)",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(ogive_cum_freq)))
points(ogive_breaks, ogive_cum_freq, pch = 16)
